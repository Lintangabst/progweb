<html>
<head><title>Pengolahan Form</title></head>
<body>
<FORM ACTION="proses03.php" METHOD="GET"! NAME=" "input">
Nama Anda : <input type=" text” name=' "nama" ><br>
<input type="submit" name="Input" value="Input">
</FORM>
</body>
</html>
