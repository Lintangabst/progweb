<head><title>Pengolahan Form ~ Text</title> </head>
<body>
<FORM ACTION="proses04.php" METHOD="POST" NAME="input">
Sahabat-sahabat Dekatku<br>
<input type="text" name="nama1"><br> <input type="text" name="nama2"><br> <input type="text" name="nama3"><br>
<input type="text" name="nama4"><br>
<input type="submit" name="Input" value="Input"> </FORM>
</body>
</html>
