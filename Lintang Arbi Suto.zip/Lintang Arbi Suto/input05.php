<html>
<head><title>Login Here</title></head>
<body>
<FORM ACTION="proses05.php" METHOD="POST" NAME="input"> <h2>Login Here...</h2>
Username : <input type="text" name="username"><br> Password: <input type="password" name="password"><br> <input type="submit" name="Login" value="Login"> <input type="reset" name="reset" value="Reset"> </FORM>
</body>
</html>
