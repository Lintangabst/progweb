<html>
<head><title>Band Favorit
2
Inputan Checkbox</title> </head>
<body>
<FORM ACTION="proses07.php" METHOD="POST" NAME="input"> <h2>Pilih Band Favorit Anda :</h2>
<input type="checkbox" name="band01" value="Padi" checked> Padi<br>
<input type="checkbox" name="band02" value="Sheila On 7"> Sheila On 7<br>
<input type="checkbox" name="band03" value="Dewa 19">
Dewa 19<br>
Ungu<br>
<input type="checkbox" name="band04" value="Ungu">
<input type="submit" name="Pilih" value="Pilih"> </FORM>
</body>
</html>
