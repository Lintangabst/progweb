<html>
<head><title>Film Kartun Favorit box</title> </head>
<body>
Inputan Combo
<FORM ACTION="proses08.php" METHOD="POST" NAME="input"> <h2>Pilih Film Kartun Favorit Anda :</h2> <select name="kartun">
<option value="Sponge Bob">Sponge Bob</option> value="Sinchan">Sinchan</option> value="Conan">Conan</option> value="Doraemon">Doraemon</option>
<option <option
<option
<option value="Dragon_Ball">Dragon Ball</option> <option value="Naruto">Naruto</option>
</select>
<input type="submit" name="Pilih" value="Pilih">
</FORM>
</body>
</html>
