<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil data dari form
    $nama = $_POST["nama"];
    $email = $_POST["email"];
    $website = $_POST["website"];
    $pesan = $_POST["pesan"];
    $jenis_kelamin = $_POST["jenis_kelamin"];

    // Menampilkan hasil input
    echo "<h2>Hasil Input:</h2>";
    echo "Nama: $nama<br>";
    echo "Email: $email<br>";
    echo "Website: $website<br>";
    echo "Pesan: $pesan<br>";
    echo "Jenis Kelamin: $jenis_kelamin<br>";
}
?>