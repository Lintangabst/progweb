<?php
if (isset($_POST['submit'])) {
  // ambil nilai input dari form
  $nama = $_POST['nama'];
  $email = $_POST['email'];
  $website = $_POST['website'];
  $pesan = $_POST['pesan'];
  $jenis_kelamin = $_POST['jenis_kelamin'];

  // lakukan validasi input
  if (empty($nama) || empty($email)) {
    echo "Nama dan email harus diisi";
  } else {
    // tampilkan data yang diinputkan
    echo "Nama: $nama<br>";
    echo "Email: $email<br>";
    echo "Website: $website<br>";
    echo "Pesan: $pesan<br>";
    echo "Jenis Kelamin: $jenis_kelamin<br>";
  }
}
?>

<form method="POST">
  <label for="nama">Nama:</label>
  <input type="text" id="nama" name="nama" required><br>

  <label for="email">Email:</label>
  <input type="email" id="email" name="email" required><br>

  <label for="website">Website:</label>
  <input type="url" id="website" name="website"><br>

  <label for="pesan">Pesan:</label>
  <textarea id="pesan" name="pesan"></textarea><br>

  <label>Jenis Kelamin:</label><br>
  <input type="radio" id="pria" name="jenis_kelamin" value="Pria" required>
  <label for="pria">Pria</label><br>
  <input type="radio" id="wanita" name="jenis_kelamin" value="Wanita" required>
  <label for="wanita">Wanita</label><br>

  <input type="submit" name="submit" value="Kirim">
</form>
