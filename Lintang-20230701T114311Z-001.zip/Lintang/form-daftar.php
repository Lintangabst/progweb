<!DOCTYPE html>
<html>
<head>
	<title>Formulir Pendaftaran Siswa Baru | SMK Coding</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
</head>
<body class="bg-gray-100">
	<header class="bg-indigo-700 text-white p-4">
		<h3 class="text-xl">Formulir Pendaftaran Siswa Baru</h3>
	</header>
	<form action="proses-pendaftaran.php" method="POST" class="p-4">
		<fieldset>
			<p class="mb-4">
				<label for="nama" class="font-bold">Nama:</label>
				<input type="text" name="nama" placeholder="Nama lengkap" class="border border-gray-300 p-2 rounded-md w-full" />
			</p>
			<p class="mb-4">
				<label for="alamat" class="font-bold">Alamat:</label>
				<textarea name="alamat" class="border border-gray-300 p-2 rounded-md w-full"></textarea>
			</p>
			<p class="mb-4">
				<label for="jenis_kelamin" class="font-bold">Jenis Kelamin:</label>
				<label class="mr-2">
					<input type="radio" name="jenis_kelamin" value="laki-laki" class="mr-1"> Laki-laki
				</label>
				<label>
					<input type="radio" name="jenis_kelamin" value="perempuan" class="mr-1"> Perempuan
				</label>
			</p>
			<p class="mb-4">
				<label for="agama" class="font-bold">Agama:</label>
				<select name="agama" class="border border-gray-300 p-2 rounded-md">
					<option>Islam</option>
					<option>Kristen</option>
					<option>Hindu</option>
					<option>Budha</option>
					<option>Atheis</option>
				</select>
			</p>
			<p class="mb-4">
				<label for="sekolah_asal" class="font-bold">Sekolah Asal:</label>
				<input type="text" name="sekolah_asal" placeholder="Nama sekolah" class="border border-gray-300 p-2 rounded-md w-full" />
			</p>

			<p class="flex justify-center">
  				<input type="submit" value="Daftar" name="daftar" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded" />
			</p>

			<p class="flex justify-center my-4">
				<a href="index.php" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Kembali</a>
			</p>

		</fieldset>
	</form>
	
</body>
</html>
