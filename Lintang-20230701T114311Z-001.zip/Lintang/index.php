<!DOCTYPE html>
<html>
<head>
	<title>Pendaftaran Siswa Baru | SMK Coding</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
</head>
<body class="bg-gray-100">
	<header class="bg-indigo-700 text-white p-4">
		<h3 class="text-xl">Pendaftaran Siswa Baru</h3>
		<h1 class="text-4xl font-bold">SMK Coding</h1>
	</header>
	<h4 class="text-lg font-bold mt-4">Menu</h4>
	<nav class="bg-gray-200 p-4">
		<?php if(isset($_GET['status'])): ?>
			<p class="mb-4">
				<?php
					if($_GET['status'] == 'sukses'){
						echo "Pendaftaran siswa baru berhasil!";
					} else {
						echo "Pendaftaran gagal!";
					}
				?>
			</p>
		<?php endif; ?>

				<div class="flex justify-center space-x-8">
			<div class="bg-white p-40 rounded shadow">
				<h2 class="text-xl font-bold mb-2 mr-4">Daftar Baru</h2>
				<a href="form-daftar.php" class="text-blue-500 hover:text-blue-700">Daftar Sekarang</a>
			</div>
			<div class="bg-white p-40 rounded shadow">
				<h2 class="text-xl font-bold mb-2">Pendaftaran</h2>
				<a href="list-siswa.php" class="text-blue-500 hover:text-blue-700">Lihat Pendaftar</a>
			</div>
		</div>

	</nav>
</body>
</html>
