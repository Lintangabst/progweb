<?php

// include database connection file

include_once("congig.php");

$id = $_GET['id'];

// include user data into table
        $result = mysqli_query($mysqli, "DELETE FROM users WHERE id=$id");

// Show Massage when user added
        header("Location:index.php");

?>