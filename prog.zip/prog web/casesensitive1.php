<!DOCTYPE html>
<html>
    <body>

        <?php
    ECHO "Hello Ican!<br>";
    echo "Hello Duray!<br>"
    EcHo "Hello Ican!<br>";
    ?>

    </body>
</html>