<!DOCTYPE html>
<html>
    <body>

    <?php
    $warna = "blue";
    $WARNA = "green";
    $WARna = "yellow";
    echo "My candy is " . $warna . "<br>";
    echo "My shoes is " . $WARNA . "<br>";
    echo "My ring is " . $WARna . "<br>";
    
    ?>
    </body>
</html>