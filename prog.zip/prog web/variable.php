
<?php
$nim = "0411500400";
$nama = "Chotimatul Musyarofah";

echo "NIM : " . $nim . "<br>";
echo "Nama : $nama";


?>
